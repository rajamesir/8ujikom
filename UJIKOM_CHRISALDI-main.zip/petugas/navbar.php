<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

<center>
<div class="card mt-5">
<div class="btn btn-secondary card-body text-white">
		<h4>ADMIN</h4>
		<a href="index.php" class="btn btn-secondary"> Beranda</a>
		<a href="data_barang.php" class="btn btn-secondary"> Data Barang</a>
		<a href="pembelian.php" class="btn btn-secondary"> transaksi</a>
		<!--<a href="stok_barang.php" class="btn btn-success">Stok Barang</a>-->
		<!-- <a href="data_pengguna.php" class="btn btn-secondary"> Data Pengguna</a> -->
		<a href="../logout.php" class="btn btn-secondary"> keluar</a>
	</div>
</div>