<?php
include "header.php";
include "navbar.php";
?>
<div class="card mt-2">
	<div class="card-body">
		<p>Selamat datang dihalaman administrator, silahkan anda bisa mengakses beberapa fitur</p>
	</div>
</div>
<br>
<br>
<?php
include "footer.php";
?>